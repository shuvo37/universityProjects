
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class DashBord extends javax.swing.JFrame {
 int dd=1;
    /**
     * Creates new form DashBord
     */
    Connection con;
      int CntAp=0,CntA=0,CntAm=0,CntB=0,CntBp=0,CntBm=0,CntC=0,CntY=0,CntF=0;
    public DashBord() {
        initComponents();
        
        
          try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/StudentInformation", "info", "info");
            
           //   update();
            
              Statement stt = con.createStatement();
                  String sqll = "SELECT * FROM DASHBOARD";
                    ResultSet rss = stt.executeQuery(sqll);
            Statement st = con.createStatement();
             Statement st1 = con.createStatement();
              Statement st2 = con.createStatement();
               Statement st3 = con.createStatement();
               
               
            String sql = "SELECT * FROM CSE2100";
             String sql11 = "SELECT * FROM CSE21003";
              String sql2 = "SELECT * FROM CSE21004";
               String sql3 = "SELECT * FROM CSE21005";
               
               
            ResultSet rs = st.executeQuery(sql);
                ResultSet rs1 = st1.executeQuery(sql11);       
                    ResultSet rs2 = st2.executeQuery(sql2);
                        ResultSet rs3 = st3.executeQuery(sql3);
                        CntAp=0;CntA=0;CntAm=0;CntB=0;CntBp=0;CntBm=0;CntC=0;CntY=0;CntF=0; 
            
              while (rss.next()&&rs.next()&&rs1.next()&&rs2.next()&&rs3.next()){
            
                //  System.out.println("yes");
                    int idd=rss.getInt("ID");
                    
                   String id=Integer.toString(idd);
               
                     String nam =rss.getString("NAME");
                     
                
                    //   System.out.println(rs.getString("NAME"));
                      double markscse2100=rs.getDouble("TOTAL");
                   
                      double markscse2103=rs1.getDouble("TOTAL");
                     
                       double markscse2104=rs2.getDouble("TOTAL");
                      
                       double markscse2105=rs3.getDouble("TOTAL");
                  
                        double cgpa=0.0;
                          double marks=0;
                          boolean bl=false;
                        
                        //  System.out.println("yes");
                        if(markscse2100!=5&&markscse2103!=5&&markscse2104!=5&&markscse2105!=5)
                        {
                          marks=((int)markscse2100+(int)markscse2103+(int)markscse2104+(int)markscse2105)/4;
                         
                             bl=true;
                       if(marks>=80&&marks<=100)
                      {
                          
                          cgpa=4.0;
                          
                      }
                       
                     else if(marks>=75&&marks<=79)
                      {
                          
                          cgpa=3.75;
                          
                      }
                       
                        else if(marks>=70&&marks<=74)
                      {
                          
                          cgpa=3.5;
                          
                      }
                       
                        else if(marks>=65&&marks<=69)
                      {
                          
                          cgpa=3.25;
                          
                      }
                       
                        else if(marks>=60&&marks<=64)
                      {
                          
                          cgpa=3.0;
                          
                      }
                       
                       else if(marks>=50&&marks<=59)
                      {
                          
                          cgpa=2.75;
                          
                      }
                      else if(marks>=40&&marks<=49)
                      {
                          
                          cgpa=2.0;
                          
                      }
                       else
                      {
                         cgpa=0.0;  
                          System.out.println(cgpa);
                          
                      }
                     
                            
                        }
                     
                        String g="";
                     if(bl&&cgpa==0.0)
                     {
                         
                         g="F";
                         CntF++;
                         
                     }
                     else if((!bl)&&cgpa==0.0)
                     {
                         
                         g="NOT YET";
                         CntY++;
                         
                         
                     }
                     
                     else if(cgpa==4.0)
                     {
                         
                        g="A+"; 
                        CntAp++;
                        
                     }
                      else if(cgpa==3.75)
                     {
                         
                        g="A"; 
                        CntA++;
                     }
                     
                      else if(cgpa==3.5)
                     {
                         
                        g="A-"; 
                        CntAm++;
                     }
                     
                      else if(cgpa==3.25)
                     {
                         
                        g="B"; 
                        CntB++;
                     }
                     
                      else if(cgpa==3.0)
                     {
                         
                        g="B+"; 
                        CntBp++;
                     }
                       else if(cgpa==2.75)
                     {
                         
                        g="B-";
                        CntBm++;
                     }
                     
                     else if(cgpa==2.0)
                     {
                         
                        g="C"; 
                         CntC++;
                     }
                     
                     else if(cgpa==0.0)
                     {
                         
                        g="F"; 
                         CntF++;
                     }
                  
                     String cg=Double.toString(cgpa);
                  
                String[] tTable = {id, nam,cg,g};

               DefaultTableModel model = (DefaultTableModel) table.getModel();
                model.addRow(tTable);
                
                
                
            String sq = "UPDATE DASHBOARD SET CGPA=?,GRADE=? WHERE ID=?";
                 
             PreparedStatement ps = con.prepareStatement(sq);
             ps.setDouble(1, cgpa);
  
             ps.setString(2, g);
               ps.setInt(3, idd);

             ps.executeUpdate();  
                
                
            }
             } catch (SQLException ex) {
            System.out.println(ex);
        }
        
        
        
     showPieChart(); 
        
        
        
        
        
    }
    
     void Display(int num)
     {
         dd=num;
         
     }
    
    class JPanelGradient extends JPanel{
        
     protected void paintComponent(Graphics g)
     {
         
       Graphics2D g2d=(Graphics2D) g;
       int width=getWidth();
       int height=getHeight();
       
       Color color1=new Color(52,143,80);
         Color color2=new Color(86,180,211);
         
         GradientPaint gp=new GradientPaint(0,0,color1,180,height,color2);
         
         g2d.setPaint(gp);
         g2d.fillRect(0,0,  width, height);
     }
        
        
    }
        
    
    
    public void showPieChart(){
        
        //create dataset
      DefaultPieDataset barDataset = new DefaultPieDataset( );
      barDataset.setValue( "A+" , new Double( CntAp ) );  
      barDataset.setValue( "A" , new Double( CntA ) );   
      barDataset.setValue( "A-" , new Double( CntAm ) );    
      barDataset.setValue( "B+" , new Double( CntBp ) ); 
        barDataset.setValue( "B" , new Double( CntB ) ); 
        barDataset.setValue( "B-" , new Double( CntBm ) ); 
        barDataset.setValue( "C" , new Double( CntC ) );
           barDataset.setValue( "NOT YET" , new Double( CntY ) );
             barDataset.setValue( "F" , new Double( CntF ) );
      
      
      //create chart
       JFreeChart piechart = ChartFactory.createPieChart("RESULT",barDataset, false,true,false);//explain
      
        PiePlot piePlot =(PiePlot) piechart.getPlot();
      
       //changing pie chart blocks colors
       piePlot.setSectionPaint("A+", new Color(255,255,102));
        piePlot.setSectionPaint("A", new Color(102,255,102));
        piePlot.setSectionPaint("A-", new Color(255,102,153));
        piePlot.setSectionPaint("B", new Color(0,204,204));
       piePlot.setSectionPaint("B+", new Color(51,20,233));
            piePlot.setSectionPaint("B-", new Color(20,4,0,0));
                 piePlot.setSectionPaint("C", new Color(204,41,248));
                      piePlot.setSectionPaint("NOT YET", new Color(204,241,12));
                      piePlot.setSectionPaint("F", new Color(204,250,252));
      
       
        piePlot.setBackgroundPaint(Color.white);
        
        //create chartPanel to display chart(graph)
        ChartPanel barChartPanel = new ChartPanel(piechart);
        panelBarChart.removeAll();
        panelBarChart.add(barChartPanel, BorderLayout.CENTER);
        panelBarChart.validate();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new JPanelGradient();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        panelBarChart = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        rSButtonMetro1 = new rojerusan.RSButtonMetro();
        rSButtonMetro3 = new rojerusan.RSButtonMetro();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));

        table.setBackground(new java.awt.Color(51, 204, 0));
        table.setBorder(new javax.swing.border.MatteBorder(null));
        table.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        table.setForeground(new java.awt.Color(51, 51, 255));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "NAME", "CGPA", "GRADE"
            }
        ));
        table.setGridColor(new java.awt.Color(51, 51, 255));
        jScrollPane1.setViewportView(table);
        if (table.getColumnModel().getColumnCount() > 0) {
            table.getColumnModel().getColumn(0).setHeaderValue("ID");
            table.getColumnModel().getColumn(1).setHeaderValue("NAME");
            table.getColumnModel().getColumn(2).setHeaderValue("CGPA");
            table.getColumnModel().getColumn(3).setHeaderValue("GRADE");
        }

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("                            DASHBORD");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setText("         PIE CHART");

        panelBarChart.setLayout(new java.awt.BorderLayout());

        jPanel3.setBackground(new java.awt.Color(51, 0, 204));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 0, 153));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8_menu_48px_1.png"))); // NOI18N
        jLabel4.setText("MENU");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/home_24px_2.png"))); // NOI18N
        jLabel3.setText("jLabel3");

        rSButtonMetro1.setBackground(new java.awt.Color(0, 153, 0));
        rSButtonMetro1.setForeground(new java.awt.Color(0, 0, 0));
        rSButtonMetro1.setText("HOME");
        rSButtonMetro1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro1ActionPerformed(evt);
            }
        });

        rSButtonMetro3.setBackground(new java.awt.Color(0, 153, 0));
        rSButtonMetro3.setForeground(new java.awt.Color(0, 0, 0));
        rSButtonMetro3.setText("BACK");
        rSButtonMetro3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(rSButtonMetro3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(rSButtonMetro1, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE))))
                .addGap(0, 23, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rSButtonMetro1, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rSButtonMetro3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 391, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(97, 97, 97))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 477, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelBarChart, javax.swing.GroupLayout.PREFERRED_SIZE, 355, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(74, 74, 74)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 91, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(8, 8, 8)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelBarChart, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(264, 264, 264))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(179, 179, 179))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(1043, 551));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void rSButtonMetro1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro1ActionPerformed
        // TODO add your handling code here:
        Home ob=new Home();
        ob.show();
        dispose();
    }//GEN-LAST:event_rSButtonMetro1ActionPerformed

    private void rSButtonMetro3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro3ActionPerformed
        // TODO add your handling code here:
          if(dd==1){
        academicInfomation ob=new  academicInfomation();
        ob.show();
        dispose();
          }
          else {
               forStudent ob=new  forStudent();
        ob.show();
        dispose();
              
          }
    }//GEN-LAST:event_rSButtonMetro3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DashBord.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DashBord.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DashBord.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DashBord.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DashBord().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panelBarChart;
    private rojerusan.RSButtonMetro rSButtonMetro1;
    private rojerusan.RSButtonMetro rSButtonMetro3;
    private javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables

    private void update() {
        
          try {
              Statement st;
     
            st = con.createStatement();
       
          
            String sql = "SELECT * FROM CSE2100";
            ResultSet rs = st.executeQuery(sql);
            
             Statement st1;
     
            st1 = con.createStatement();
       
          
            String sql1 = "SELECT * FROM CSE21003";
            ResultSet rs1 = st1.executeQuery(sql1);
            
             Statement st2;
     
            st2 = con.createStatement();
       
          
            String sql2 = "SELECT * FROM CSE21004";
            ResultSet rs2 = st2.executeQuery(sql2);
            
             Statement st3;
     
            st3 = con.createStatement();
       
          
            String sql3 = "SELECT * FROM CSE21005";
            ResultSet rs3 = st3.executeQuery(sql3);
            
              while (rs.next()) {
               
                String id = String.valueOf(rs.getInt("ID"));
              //String nam = rs.getString("Name");
              
                String mar = String.valueOf(rs.getDouble("MARKS"));
                String ct1 = String.valueOf(rs.getDouble("CT1"));
                String ct2 = String.valueOf(rs.getDouble("CT2"));
                String ct3 = String.valueOf(rs.getDouble("CT3"));
                String ct4 = String.valueOf(rs.getDouble("CT4"));
                
                 double cct1=Double.parseDouble(ct1);
                    double cct2=Double.parseDouble(ct2);
                   double cct3=Double.parseDouble(ct3);
                    double cct4=Double.parseDouble(ct4);
                          
                       double mi3=Math.min(cct4,Math.min(cct3,Math.min(cct1, cct2)));
                       
                           String atten = String.valueOf(rs.getInt("ATTENDANCE"));
                          double att=Double.parseDouble(atten);
                          
                       
                         double totalCt=0;
                totalCt=((cct1+cct2+cct3+cct4)-mi3)/3;
               
                    if(att<=20)
                          {
                            totalCt+=5;  
                          }
                    else
                    {
                     totalCt+=10;  
                    }
               
               
               
                   double mr=Double.parseDouble(mar);
                      totalCt+=mr;
                DecimalFormat df = new DecimalFormat("#0.00");
                 String tot=df.format(totalCt);
                
                      String g="";
                      if(totalCt>=80&&totalCt<=100)
                      {
                          
                         g="A+"; 
                          
                      }
                      else if(totalCt>=70&&totalCt<=79)
                      {
                          
                         g="A"; 
                          
                      }
                      else if(totalCt>=60&&totalCt<=69)
                      {
                          
                         g="A-"; 
                          
                      }
                       else if(totalCt>=50&&totalCt<=59)
                      {
                          
                         g="B+"; 
                          
                      }
                        else if(totalCt>=40&&totalCt<=49)
                      {
                          
                         g="B-"; 
                          
                      }
                       else if(totalCt>=40&&totalCt<=49)
                      {
                          
                         g="B-"; 
                          
                      }
                      else if(totalCt>=0&&totalCt<=39)
                      {
                          
                         g="F"; 
                          
                      }
                      else 
                      {
                         g="inValid data";    
                      }
               
                       
             /*    String sql1 = "UPDATE CSE2100 SET  TOTAL = ?, GRADE = ? WHERE ID = ?";
                  PreparedStatement ps = con.prepareStatement(sql1);
                  ps.setString(1, tot); // New value for COLUMN_NAME1
                  ps.setString(2, g); // New value for COLUMN_NAME2
                  ps.setString(3, id);    // SID value to identify the row to update
                  ps.executeUpdate();*/
            
               
              }
          
               
           } catch (SQLException ex) {
            Logger.getLogger(cse2100.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        
        
    }
}
